# Finmetrics

### A python package to perform financial operations